#include <iostream>
#include <string>
#include <chrono>
#include <thread>
#include <utility>
#include <ctime>
#include "sensor/GPSSensor.h"

// Helper to get formatted time string (YYYY-MM-DD HH:MM:SS)
std::string getCurrentTimeString(int secondsOffset) {
    static std::tm baseTime = {0,16,11,31,5,125}; // 2025-05-31 11:16:46
    std::time_t t = std::mktime(&baseTime) + secondsOffset;
    char buf[20];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", std::localtime(&t));
    return std::string(buf);
}

#ifdef _WIN32
#include <winsock2.h>
#else
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

int main(int argc, char* argv[]) {
    if (argc < 5) {
        std::cerr << "Usage: " << argv[0] << " <ip> <id> <csv_file> <num_ports>\n";
        return 1;
    }
    std::string server_ip = argv[1];
    std::string ebike_id = argv[2];
    std::string csvFile = argv[3];
    int num_ports = std::stoi(argv[4]);
    int gateway_port = 8080; // Default, update if needed

    // Socket setup
#ifdef _WIN32
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2,2), &wsaData);
#endif
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        std::cerr << "[EBCLIENT] Failed to create socket\n";
        return 1;
    }
    sockaddr_in server_addr{};
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(gateway_port);
    server_addr.sin_addr.s_addr = inet_addr(server_ip.c_str());

    std::cout << "[EBCLIENT] eBike Client started on: " << server_ip << ":" << gateway_port << ".\n";
    std::cout << "[CSVHALManager] Device attached to port 2." << std::endl;
    GPSSensor gps(csvFile);
    int recordIdx = 0;
    int timeOffset = 0;
    while (gps.hasNext()) {
        std::pair<double, double> latlon = gps.next();
        std::string timestamp = getCurrentTimeString(timeOffset);
        // Create JSON message
        char json_msg[256];
        snprintf(json_msg, sizeof(json_msg), "{\"id\":\"%s\",\"timestamp\":\"%s\",\"lat\":%.6f,\"lon\":%.6f}",
            ebike_id.c_str(), timestamp.c_str(), latlon.first, latlon.second);
        // Send UDP message
        int sent = sendto(sockfd, json_msg, strlen(json_msg), 0, (sockaddr*)&server_addr, sizeof(server_addr));
        if (sent > 0) {
            std::cout << "[EBCLIENT] Sent: " << json_msg << std::endl;
            // Wait for ACK
            char ack_buf[16];
#ifdef _WIN32
            int addr_len = sizeof(server_addr);
#else
            socklen_t addr_len = sizeof(server_addr);
#endif
            int ack_len = recvfrom(sockfd, ack_buf, sizeof(ack_buf) - 1, 0, (sockaddr*)&server_addr, &addr_len);
            if (ack_len > 0) {
                ack_buf[ack_len] = '\0';
                std::cout << "[EBCLIENT] Received ACK: " << ack_buf << std::endl;
            }
        }
        std::cout << "[EBCLIENT] " << timestamp << " gps: {\"lat\":" << latlon.first << ",\"lon\":" << latlon.second << "}(unlocked)" << std::endl;
        timeOffset += 5;
        recordIdx++;
        std::this_thread::sleep_for(std::chrono::milliseconds(10)); // Simulate delay
    }
    std::cout << "[CSVHALManager] Device released from port 2." << std::endl;
    std::cout << "[EBCLIENT] Shutting down." << std::endl;
#ifdef _WIN32
    closesocket(sockfd);
    WSACleanup();
#else
    close(sockfd);
#endif
    return 0;
}
