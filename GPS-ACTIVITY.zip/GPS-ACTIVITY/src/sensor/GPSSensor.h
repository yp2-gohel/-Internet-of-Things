#ifndef GPSSENSOR_H
#define GPSSENSOR_H

#include <string>
#include <fstream>
#include <vector>
#include <utility>
#include <sstream>
#include <cstdlib>

class GPSSensor {
public:
    GPSSensor(const std::string& csvFilePath) : currentIdx(0) { loadData(csvFilePath); }
    bool hasNext() const { return currentIdx < gpsData.size(); }
    std::pair<double, double> next() {
        if (!hasNext()) return std::make_pair(0.0, 0.0);
        return gpsData[currentIdx++];
    }
    void reset() { currentIdx = 0; }
private:
    std::vector<std::pair<double, double>> gpsData;
    size_t currentIdx;
    void loadData(const std::string& csvFilePath) {
        std::ifstream file(csvFilePath);
        std::string line;
        while (std::getline(file, line)) {
            std::istringstream ss(line);
            std::string latStr, lonStr;
            if (std::getline(ss, latStr, ',') && std::getline(ss, lonStr, ',')) {
                try {
                    double lat = std::stod(latStr);
                    double lon = std::stod(lonStr);
                    gpsData.emplace_back(lat, lon);
                } catch (...) {
                    // Ignore malformed lines
                }
            }
        }
    }
};

#endif // GPSSENSOR_H
