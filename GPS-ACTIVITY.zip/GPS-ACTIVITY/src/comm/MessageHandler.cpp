#include "MessageHandler.h"
#include <iostream>
#include <Poco/JSON/Object.h>
#include <Poco/JSON/Parser.h>
#include <Poco/JSON/Array.h>
#include <Poco/Dynamic/Var.h>

MessageHandler::MessageHandler() {}

void MessageHandler::handleMessage(const std::string& msg) {
    try {
        Poco::JSON::Parser parser;
        Poco::Dynamic::Var result = parser.parse(msg);
        Poco::JSON::Object::Ptr j = result.extract<Poco::JSON::Object::Ptr>();
        EBikeGeoJSON ebike;
        ebike.ebike_id = j->getValue<std::string>("id");
        ebike.timestamp = j->getValue<std::string>("timestamp");
        double lat = j->getValue<double>("lat");
        double lon = j->getValue<double>("lon");
        // Build GeoJSON Feature
        Poco::JSON::Object::Ptr geometry = new Poco::JSON::Object();
        geometry->set("type", "Point");
        Poco::JSON::Array::Ptr coords = new Poco::JSON::Array();
        coords->add(lon);
        coords->add(lat);
        geometry->set("coordinates", coords);
        Poco::JSON::Object::Ptr properties = new Poco::JSON::Object();
        properties->set("id", ebike.ebike_id);
        properties->set("timestamp", ebike.timestamp);
        properties->set("status", "unlocked");
        ebike.geojson = new Poco::JSON::Object();
        ebike.geojson->set("type", "Feature");
        ebike.geojson->set("geometry", geometry);
        ebike.geojson->set("properties", properties);
        std::lock_guard<std::mutex> lock(mtx);
        ebikes.push_back(ebike);
        std::cout << "[MHANDLER] DATA from " << ebike.ebike_id << " at " << ebike.timestamp
                  << ": lat=" << lat << ", lon=" << lon << " (unlocked)" << std::endl;
    } catch (std::exception& e) {
        std::cerr << "[MHANDLER] Failed to parse message: " << e.what() << std::endl;
    }
}

std::vector<MessageHandler::EBikeGeoJSON> MessageHandler::getEBikes() {
    std::lock_guard<std::mutex> lock(mtx);
    return ebikes;
}
