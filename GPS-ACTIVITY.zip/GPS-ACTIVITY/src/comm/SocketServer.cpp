#include "SocketServer.h"
#include <iostream>
#ifdef _WIN32
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

SocketServer::SocketServer(int port_, MessageHandler& handler_)
    : port(port_), handler(handler_), running(false) {}

void SocketServer::start() {
    running = true;
    serverThread = std::thread(&SocketServer::run, this);
}

void SocketServer::stop() {
    running = false;
    if (serverThread.joinable()) serverThread.join();
}

void SocketServer::run() {
#ifdef _WIN32
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2,2), &wsaData);
#endif
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        std::cerr << "[SOCKETS] Failed to create socket\n";
        return;
    }
    sockaddr_in server_addr{};
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);
    if (bind(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        std::cerr << "[SOCKETS] Failed to bind socket\n";
#ifdef _WIN32
        closesocket(sockfd);
        WSACleanup();
#else
        close(sockfd);
#endif
        return;
    }
    std::cout << "[SOCKETS] Socket server started on:" << port << ".\n";
    char buffer[1024];
    while (running) {
        sockaddr_in client_addr{};
#ifdef _WIN32
        int addrlen = sizeof(client_addr);
#else
        socklen_t addrlen = sizeof(client_addr);
#endif
        int len = recvfrom(sockfd, buffer, sizeof(buffer) - 1, 0, (struct sockaddr*)&client_addr, &addrlen);
        if (len > 0) {
            buffer[len] = '\0';
            handler.handleMessage(std::string(buffer));
            // Send ACK back to client
            const char* ack = "ACK";
            sendto(sockfd, ack, strlen(ack), 0, (struct sockaddr*)&client_addr, addrlen);
        }
    }
#ifdef _WIN32
    closesocket(sockfd);
    WSACleanup();
#else
    close(sockfd);
#endif
}
