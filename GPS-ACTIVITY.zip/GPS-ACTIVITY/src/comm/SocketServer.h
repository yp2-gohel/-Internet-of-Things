#ifndef SOCKETSERVER_H
#define SOCKETSERVER_H

#include "MessageHandler.h"
#include <thread>
#include <atomic>

class SocketServer {
public:
    SocketServer(int port, MessageHandler& handler);
    void start();
    void stop();
private:
    int port;
    MessageHandler& handler;
    std::thread serverThread;
    std::atomic<bool> running;
    void run();
};

#endif // SOCKETSERVER_H
