#ifndef MESSAGEHANDLER_H
#define MESSAGEHANDLER_H

#include <string>
#include <vector>
#include <mutex>
#include <Poco/JSON/Object.h>
#include <Poco/JSON/Parser.h>
#include <Poco/Dynamic/Var.h>

class MessageHandler {
public:
    struct EBikeGeoJSON {
        Poco::JSON::Object::Ptr geojson;
        std::string ebike_id;
        std::string timestamp;
    };

    MessageHandler();
    void handleMessage(const std::string& msg);
    std::vector<EBikeGeoJSON> getEBikes();
private:
    std::vector<EBikeGeoJSON> ebikes;
    std::mutex mtx;
};

#endif // MESSAGEHANDLER_H
