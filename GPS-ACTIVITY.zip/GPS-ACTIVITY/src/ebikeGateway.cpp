// eBike Gateway main server application
#include "comm/SocketServer.h"
#include "comm/MessageHandler.h"
#include <iostream>
#include <thread>
#include <Poco/Net/HTTPServer.h>
#include <Poco/Net/HTTPRequestHandler.h>
#include <Poco/Net/HTTPRequestHandlerFactory.h>
#include <Poco/Net/ServerSocket.h>
#include <Poco/Net/HTTPServerParams.h>
#include <Poco/Net/HTTPServerRequest.h>
#include <Poco/Net/HTTPServerResponse.h>
#include <Poco/Path.h>
#include <Poco/File.h>
#include <fstream>
#include <streambuf>

class StaticFileHandler : public Poco::Net::HTTPRequestHandler {
public:
    void handleRequest(Poco::Net::HTTPServerRequest& request, Poco::Net::HTTPServerResponse& response) override {
        std::string path = request.getURI();
        if (path == "/api/ebikes") {
            // Serve GPS data from CSV as JSON
            response.setStatus(Poco::Net::HTTPResponse::HTTP_OK);
            response.setContentType("application/json");
            std::ifstream infile("data/sim-eBike-1.csv");
            if (!infile.is_open()) {
                std::cerr << "[ERROR] Could not open CSV: data/sim-eBike-1.csv\n";
                response.send() << "[]";
                return;
            }
            std::string line;
            std::vector<std::string> lines;
            while (std::getline(infile, line)) {
                if (!line.empty()) lines.push_back(line);
            }
            std::cout << "[INFO] Loaded " << lines.size() << " lines from CSV.\n";
            // CSV format: lat,lon (no timestamp/status)
            std::ostringstream oss;
            oss << "[";
            int start = (int)lines.size() > 5 ? (int)lines.size() - 5 : 0;
            int id = 1;
            for (int i = start; i < (int)lines.size(); ++i, ++id) {
                std::istringstream ss(lines[i]);
                std::string lat, lon;
                std::getline(ss, lat, ',');
                std::getline(ss, lon, ',');
                oss << (id > 1 ? "," : "");
                oss << "{\"id\":" << id
                    << ",\"lat\":" << lat
                    << ",\"lng\":" << lon
                    << ",\"status\":\"unlocked\""
                    << ",\"last_seen\":\"-\"}";
            }
            oss << "]";
            std::cout << "[INFO] JSON sent: " << oss.str() << std::endl;
            response.send() << oss.str();
            return;
        }
        if (path == "/") path = "/index.html";
        std::string filePath = "www" + path;
        Poco::File file(filePath);
        if (file.exists() && file.isFile()) {
            std::ifstream t(filePath, std::ios::in | std::ios::binary);
            std::string str((std::istreambuf_iterator<char>(t)), std::istreambuf_iterator<char>());
            response.setStatus(Poco::Net::HTTPResponse::HTTP_OK);
            // Simple content type detection
            if (filePath.size() >= 5 && filePath.substr(filePath.size()-5) == ".html")
                response.setContentType("text/html");
            else if (filePath.size() >= 3 && filePath.substr(filePath.size()-3) == ".js")
                response.setContentType("application/javascript");
            else if (filePath.size() >= 4 && filePath.substr(filePath.size()-4) == ".css")
                response.setContentType("text/css");
            else
                response.setContentType("application/octet-stream");
            response.sendBuffer(str.data(), str.size());
        } else {
            response.setStatus(Poco::Net::HTTPResponse::HTTP_NOT_FOUND);
            response.setContentType("text/plain");
            response.send() << "404 Not Found";
        }
    }
};

class StaticFileHandlerFactory : public Poco::Net::HTTPRequestHandlerFactory {
public:
    Poco::Net::HTTPRequestHandler* createRequestHandler(const Poco::Net::HTTPServerRequest& request) override {
        return new StaticFileHandler();
    }
};

int main() {
    int socket_port = 8080; // Update as per your assignment table if needed
    int web_port = 8081;    // Update as per your assignment table if needed

    MessageHandler handler;
    SocketServer socketServer(socket_port, handler);

    // Start socket server in a separate thread
    socketServer.start();

    // Start Poco HTTP server for static files
    Poco::Net::ServerSocket svs(web_port);
    Poco::Net::HTTPServer srv(new StaticFileHandlerFactory(), svs, new Poco::Net::HTTPServerParams);
    srv.start();

    std::cout << "[WEBS] Web server started on http://localhost:" << web_port << ".\n";
    std::cout << "[WEBS] Press Ctrl+C to stop the server...\n";

    // Keep main thread alive
    while (true) {
        std::this_thread::sleep_for(std::chrono::seconds(60));
    }
    // socketServer.stop(); // Not reached, but would be used for graceful shutdown
    return 0;
}
