// main.js for eBike Gateway Web App
// Enhanced: auto-refresh, color-coded markers, highlight locked bikes

document.addEventListener('DOMContentLoaded', function() {
    var map = L.map('map').setView([51.5074, -0.1278], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    var markers = [];

    // Store last seen times in JS memory
    var lastSeenMap = {};

    function getNowStr() {
        const now = new Date();
        return now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0') + ' ' +
            String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0') + ':' + String(now.getSeconds()).padStart(2, '0');
    }

    function updateMapAndTable() {
        // Remove old markers
        markers.forEach(m => map.removeLayer(m));
        markers = [];
        // Clear table
        var tableBody = document.getElementById('ebike-table-body');
        tableBody.innerHTML = '';

        fetch('/api/ebikes')
            .then(res => res.json())
            .then(data => {
                var bounds = [];
                data.forEach(function(bike) {
                    // Use updated last seen if exists
                    var lastSeen = lastSeenMap[bike.id] || bike.last_seen;
                    // Marker icon color
                    var icon = L.icon({
                        iconUrl: bike.status === 'locked' ? 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png' : 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png',
                        shadowUrl: 'https://unpkg.com/leaflet@1.9.3/dist/images/marker-shadow.png',
                        iconSize: [25, 41],
                        iconAnchor: [12, 41],
                        popupAnchor: [1, -34],
                        shadowSize: [41, 41]
                    });
                    var marker = L.marker([bike.lat, bike.lng], {icon: icon}).addTo(map);
                    marker.bindPopup(`<b>eBike #${bike.id}</b><br>Status: <b>${bike.status}</b><br>Last seen: <span id='popup-lastseen-${bike.id}'>${lastSeen}</span>`);
                    marker.on('click', function() {
                        const nowStr = getNowStr();
                        lastSeenMap[bike.id] = nowStr;
                        // Update table
                        var row = document.getElementById('row-' + bike.id);
                        if (row) row.querySelector('.last-seen').innerText = nowStr;
                        // Update popup
                        setTimeout(function() {
                            var popupSpan = document.getElementById('popup-lastseen-' + bike.id);
                            if (popupSpan) popupSpan.innerText = nowStr;
                        }, 100);
                    });
                    markers.push(marker);
                    bounds.push([bike.lat, bike.lng]);
                    // Table row
                    var row = document.createElement('tr');
                    row.id = 'row-' + bike.id;
                    if (bike.status === 'locked') row.style.background = '#ffeaea';
                    row.innerHTML = `<td>${bike.id}</td><td>${bike.lat.toFixed(5)}</td><td>${bike.lng.toFixed(5)}</td><td>${bike.status}</td><td class='last-seen'>${lastSeen}</td>`;
                    tableBody.appendChild(row);
                });
                if (bounds.length > 0) {
                    map.fitBounds(bounds, {padding: [30, 30]});
                }
            });
    }

    updateMapAndTable();
    setInterval(updateMapAndTable, 5000);
});
