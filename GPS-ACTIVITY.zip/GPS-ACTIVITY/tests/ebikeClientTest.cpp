#include "catch.hpp"

class MockHALManager {
public:
    bool attached = false;
    bool released = false;
    void attach(int port) { attached = true; attachedPort = port; }
    void release(int port) { released = true; releasedPort = port; }
    int attachedPort = -1;
    int releasedPort = -1;
};

TEST_CASE("HALManager attach and release", "[ebikeClient]") {
    MockHALManager hal;
    hal.attach(1);
    REQUIRE(hal.attached);
    REQUIRE(hal.attachedPort == 1);
    hal.release(1);
    REQUIRE(hal.released);
    REQUIRE(hal.releasedPort == 1);
}
