#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "../src/sensor/GPSSensor.h"
#include <string>
#include <sstream>

std::string format_gps_json(double lat, double lon) {
    std::ostringstream oss;
    oss.precision(6);
    oss << std::fixed;
    oss << "{\"lat\":" << lat << ",\"lon\":" << lon << "}";
    return oss.str();
}

TEST_CASE("GPSSensor Construction and Data Count", "[GPSSensor]") {
    GPSSensor gps("data/sim-eBike-1.csv");
    int count = 0;
    while (gps.hasNext()) {
        gps.next();
        count++;
    }
    REQUIRE(count == 5);
}

TEST_CASE("GPSSensor JSON Output Format", "[GPSSensor]") {
    GPSSensor gps("data/sim-eBike-1.csv");
    if (gps.hasNext()) {
        auto latlon = gps.next();
        std::string json = format_gps_json(latlon.first, latlon.second);
        REQUIRE(json == "{\"lat\":51.457130,\"lon\":-2.557153}");
    } else {
        FAIL("No data in GPSSensor");
    }
}
