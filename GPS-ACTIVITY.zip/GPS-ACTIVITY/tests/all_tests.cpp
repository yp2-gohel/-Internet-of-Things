#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "../src/sensor/GPSSensor.h"
#include <sstream>

// Helper for JSON formatting for test
std::string format_gps_json(double lat, double lon) {
    std::ostringstream oss;
    oss.precision(6);
    oss << std::fixed;
    oss << "{\"lat\":" << lat << ",\"lon\":" << lon << "}";
    return oss.str();
}

TEST_CASE("GPSSensor Construction and Data Count", "[GPSSensor]") {
    GPSSensor gps("data/sim-eBike-1.csv");
    int count = 0;
    while (gps.hasNext()) { gps.next(); count++; }
    REQUIRE(count == 5);
}

TEST_CASE("GPSSensor JSON Output Format", "[GPSSensor]") {
    GPSSensor gps("data/sim-eBike-1.csv");
    if (gps.hasNext()) {
        auto latlon = gps.next();
        std::string json = format_gps_json(latlon.first, latlon.second);
        REQUIRE(json == "{\"lat\":51.457130,\"lon\":-2.557153}");
    } else {
        FAIL("No data in GPSSensor");
    }
}

class MockHALManager {
public:
    bool attached = false;
    bool released = false;
    void attach(int port) { attached = true; attachedPort = port; }
    void release(int port) { released = true; releasedPort = port; }
    int attachedPort = -1;
    int releasedPort = -1;
};

TEST_CASE("HALManager attach and release", "[ebikeClient]") {
    MockHALManager hal;
    hal.attach(1);
    REQUIRE(hal.attached);
    REQUIRE(hal.attachedPort == 1);
    hal.release(1);
    REQUIRE(hal.released);
    REQUIRE(hal.releasedPort == 1);
}
